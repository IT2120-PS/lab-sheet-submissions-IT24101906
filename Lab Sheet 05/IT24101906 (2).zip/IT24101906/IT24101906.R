getwd()
setwd("C:/Users/piyum/OneDrive/Desktop/IT24101884")

##1
Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
head(Times)

##2
breaks <- seq(20,70, length.out = 10)

hist(Times$Delivery_Time, breaks = breaks, right = FALSE, main = "Histogram of Delivery Times", xlab = "Delivery Time", col = "skyblue", border = "black")

##4
hist_data <- hist(Times$Delivery_Time, breaks = breaks, plot = FALSE)
cum_freq <- cumsum(hist_data$counts)

plot(hist_data$breaks[-1], cum_freq, type = "o", main = "Cumulative Frequency Polygon (Ogive)", xlab = "Delivery Time", ylab = "Cumulative Frequency", col = "red", pch = 16)
